'''--->This package is to generate a text file with random inputs to the attributes.
   --->The attributes are:
   -Name
   -Gender
   -Birth Date
   -Death Date
   -Region
   -Achievements
   -Others Names'''
