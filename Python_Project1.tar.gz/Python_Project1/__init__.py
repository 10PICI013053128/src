'''--->This is the package which has the main program.
   --->It creates the dictionary reading the input from the text file "database.txt"
   --->It has three modules in it:
       -main.py
       -database.txt
       -__init__.py

   --->It processes the queries given in the command line argument and displays the result.'''


